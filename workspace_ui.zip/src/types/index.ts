export type Role = 'USER' | 'ADMIN';

export interface User {
  id: string;
  name: string;
  email: string;
  role: Role;
}

export interface Workspace {
  id: string;
  name: string;
  description: string;
  imageUrl?: string;
  resourceCount: number;
}

export interface Resource {
  id: string;
  workspaceId: string;
  name: string;
  description: string;
  status: 'AVAILABLE' | 'BORROWED' | 'MAINTENANCE' | 'REQUESTED';
  requiresApproval: boolean;
  imageUrl?: string;
}

export interface BorrowRequest {
  id: string;
  resourceId: string;
  resourceName: string;
  userId: string;
  userName: string;
  status: 'PENDING' | 'APPROVED' | 'REJECTED' | 'RETURNED';
  requestDate: string;
  returnDate?: string;
}
