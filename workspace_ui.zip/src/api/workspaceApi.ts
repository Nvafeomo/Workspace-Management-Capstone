import { Workspace } from '../types';
import { supabase } from '../lib/supabase';

const MOCK_WORKSPACES: Workspace[] = [
  {
    id: 'ws-1',
    name: '3D Printing Lab',
    description: 'Advanced additive manufacturing facility with FDM and SLA printers.',
    resourceCount: 12,
  },
  {
    id: 'ws-2',
    name: 'Robotics Workshop',
    description: 'Space for building and testing autonomous systems and drones.',
    resourceCount: 8,
  },
  {
    id: 'ws-3',
    name: 'Media Studio',
    description: 'Professional video and audio recording equipment and editing suites.',
    resourceCount: 15,
  },
  {
    id: 'ws-4',
    name: 'Electronics Bench',
    description: 'Soldering stations, oscilloscopes, and component inventory.',
    resourceCount: 20,
  }
];

export const workspaceApi = {
  getAll: async (): Promise<Workspace[]> => {
    const { data, error } = await supabase
      .from('workspaces')
      .select('*');

    if (error) {
      console.warn('Supabase Workspace API failed, using mock data', error);
      return MOCK_WORKSPACES;
    }
    return data as Workspace[];
  },

  getById: async (id: string): Promise<Workspace | undefined> => {
    const { data, error } = await supabase
      .from('workspaces')
      .select('*')
      .eq('id', id)
      .single();

    if (error) {
      console.warn(`Supabase Workspace API for ${id} failed, using mock data`, error);
      return MOCK_WORKSPACES.find(ws => ws.id === id);
    }
    return data as Workspace;
  },

  create: async (data: Omit<Workspace, 'id' | 'resourceCount'>): Promise<Workspace> => {
    const { data: created, error } = await supabase
      .from('workspaces')
      .insert([data])
      .select()
      .single();

    if (error) {
      console.warn('Supabase Create Workspace failed, using mock success', error);
      return {
        ...data,
        id: `ws-${Math.random().toString(36).substr(2, 9)}`,
        resourceCount: 0
      };
    }
    return created as Workspace;
  }
};
