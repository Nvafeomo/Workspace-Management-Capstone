import { BorrowRequest } from '../types';
import { supabase } from '../lib/supabase';

const MOCK_REQUESTS: BorrowRequest[] = [
  {
    id: 'req-1',
    resourceId: 'res-1',
    resourceName: 'Ultimaker S5',
    userId: 'user-1',
    userName: 'John Doe',
    status: 'PENDING',
    requestDate: new Date().toISOString()
  },
  {
    id: 'req-2',
    resourceId: 'res-2',
    resourceName: 'Formlabs Form 3',
    userId: 'user-2',
    userName: 'Jane Smith',
    status: 'PENDING',
    requestDate: new Date().toISOString()
  }
];

export const borrowApi = {
  createRequest: async (resourceId: string, userId: string): Promise<BorrowRequest> => {
    // In a real app, we'd fetch the resource name and user name first or use a RPC
    const { data: created, error } = await supabase
      .from('borrow_requests')
      .insert([{ 
        resourceId, 
        userId, 
        status: 'PENDING',
        requestDate: new Date().toISOString()
      }])
      .select()
      .single();

    if (error) {
      console.warn('Supabase Borrow Request failed, using mock success', error);
      return {
        id: `req-${Math.random().toString(36).substr(2, 9)}`,
        resourceId,
        resourceName: 'Mock Resource',
        userId,
        userName: 'Current User',
        status: 'PENDING',
        requestDate: new Date().toISOString()
      };
    }

    // Update resource status to REQUESTED
    await supabase
      .from('resources')
      .update({ status: 'REQUESTED' })
      .eq('id', resourceId);

    return created as BorrowRequest;
  },

  getApprovals: async (): Promise<BorrowRequest[]> => {
    const { data, error } = await supabase
      .from('borrow_requests')
      .select('*')
      .eq('status', 'PENDING');

    if (error) {
      console.warn('Supabase Approvals API failed, using mock data', error);
      return MOCK_REQUESTS;
    }
    return data as BorrowRequest[];
  },

  updateStatus: async (id: string, status: 'APPROVED' | 'REJECTED'): Promise<BorrowRequest> => {
    const { data: updated, error } = await supabase
      .from('borrow_requests')
      .update({ status })
      .eq('id', id)
      .select()
      .single();

    if (error) {
      console.warn(`Supabase Update Status API for ${id} failed, using mock success`, error);
      const req = MOCK_REQUESTS.find(r => r.id === id);
      return {
        ...(req || MOCK_REQUESTS[0]),
        status
      };
    }

    // Update resource status based on approval/rejection
    const resourceStatus = status === 'APPROVED' ? 'BORROWED' : 'AVAILABLE';
    await supabase
      .from('resources')
      .update({ status: resourceStatus })
      .eq('id', updated.resourceId);

    return updated as BorrowRequest;
  }
};
