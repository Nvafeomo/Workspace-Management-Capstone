import { Resource } from '../types';
import { supabase } from '../lib/supabase';

const MOCK_RESOURCES: Resource[] = [
  {
    id: 'res-1',
    workspaceId: 'ws-1',
    name: 'Ultimaker S5',
    description: 'Large-scale industrial 3D printer with dual extrusion.',
    status: 'AVAILABLE',
    requiresApproval: true,
    imageUrl: 'https://picsum.photos/seed/printer1/800/600'
  },
  {
    id: 'res-2',
    workspaceId: 'ws-1',
    name: 'Formlabs Form 3',
    description: 'High-precision SLA resin printer for detailed models.',
    status: 'BORROWED',
    requiresApproval: true,
    imageUrl: 'https://picsum.photos/seed/printer2/800/600'
  },
  {
    id: 'res-3',
    workspaceId: 'ws-2',
    name: 'Universal Robots UR5',
    description: 'Collaborative robotic arm for automation tasks.',
    status: 'AVAILABLE',
    requiresApproval: true,
    imageUrl: 'https://picsum.photos/seed/robot1/800/600'
  },
  {
    id: 'res-4',
    workspaceId: 'ws-3',
    name: 'Sony A7III Camera',
    description: 'Full-frame mirrorless camera for high-quality video.',
    status: 'AVAILABLE',
    requiresApproval: false,
    imageUrl: 'https://picsum.photos/seed/camera1/800/600'
  }
];

export const resourceApi = {
  getByWorkspace: async (workspaceId: string): Promise<Resource[]> => {
    const { data, error } = await supabase
      .from('resources')
      .select('*')
      .eq('workspaceId', workspaceId);

    if (error) {
      console.warn(`Supabase Resource API for workspace ${workspaceId} failed, using mock data`, error);
      return MOCK_RESOURCES.filter(r => r.workspaceId === workspaceId);
    }
    return data as Resource[];
  },

  getById: async (id: string): Promise<Resource | undefined> => {
    const { data, error } = await supabase
      .from('resources')
      .select('*')
      .eq('id', id)
      .single();

    if (error) {
      console.warn(`Supabase Resource API for ${id} failed, using mock data`, error);
      return MOCK_RESOURCES.find(r => r.id === id);
    }
    return data as Resource;
  },

  create: async (data: Omit<Resource, 'id'>): Promise<Resource> => {
    const { data: created, error } = await supabase
      .from('resources')
      .insert([data])
      .select()
      .single();

    if (error) {
      console.warn('Supabase Create Resource failed, using mock success', error);
      return {
        ...data,
        id: `res-${Math.random().toString(36).substr(2, 9)}`
      };
    }
    return created as Resource;
  },

  updateStatus: async (id: string, status: Resource['status']): Promise<Resource> => {
    const { data: updated, error } = await supabase
      .from('resources')
      .update({ status })
      .eq('id', id)
      .select()
      .single();

    if (error) {
      console.warn(`Supabase Update Resource Status failed for ${id}`, error);
      const res = MOCK_RESOURCES.find(r => r.id === id);
      return { ...(res || MOCK_RESOURCES[0]), status };
    }
    return updated as Resource;
  }
};
